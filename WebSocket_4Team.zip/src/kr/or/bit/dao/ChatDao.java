package kr.or.bit.dao;

import java.util.List;

import kr.or.bit.dto.ChatRoom;

public interface ChatDao {

	public int insertChat(ChatRoom chat);

	

	public List<ChatRoom> getChats();

	public int deleteChatRoomByOwner(String owner);

	
}
