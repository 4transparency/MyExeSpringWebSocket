
package com.javainuse.controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.messaging.handler.annotation.DestinationVariable;
import org.springframework.messaging.handler.annotation.MessageMapping;
import org.springframework.messaging.handler.annotation.Payload;
import org.springframework.messaging.simp.SimpMessageHeaderAccessor;
import org.springframework.messaging.simp.SimpMessageSendingOperations;
import org.springframework.stereotype.Controller;

import com.javainuse.domain.Message;

import static java.lang.String.format;

@Controller
public class ChatRoomController {
	
	private static final Logger logger = LoggerFactory.getLogger(ChatRoomController.class);
	
	@Autowired
	private SimpMessageSendingOperations messagingTemplate;
	
	@MessageMapping("/chat/{roomId}/sendMessage")
	public void sendMessage(@DestinationVariable String roomId, @Payload Message chatMessage) {
		logger.info(roomId+" Chat messahe recieved is "+chatMessage.getContent());
		
		
		messagingTemplate.convertAndSend(format("/chat-room/%s", roomId), chatMessage);
		
	}
	
	@MessageMapping("/chat/{roomId}/addUser")
	public void addUser(@DestinationVariable String roomId, @Payload Message chatMessage,
			 SimpMessageHeaderAccessor headerAccessor) {
		System.out.println("이쪽으로 들어오는 룸아이디는??" + roomId);
		System.out.println("심플메세지헤더 액세서 실헝  :" + headerAccessor.getSessionAttributes());
		System.out.println("여기로 들어오는 메세지 디티오의 데이터는 멀까??" + chatMessage);
		String currentRoomId = (String) headerAccessor.getSessionAttributes().put("room_id", roomId);
		System.out.println("심플메세지헤더 액세서 실헝  :" + headerAccessor.getSessionAttributes());
		System.out.println("current RoomID ??" + currentRoomId);
		 if (currentRoomId != null) {
			 Message leaveMessage = new Message();
			 leaveMessage.setType(Message.MessageType.LEAVE);
			 leaveMessage.setSender(chatMessage.getSender());
			 messagingTemplate.convertAndSend(format("/chat-room/%s", currentRoomId), leaveMessage);
		 }
		 headerAccessor.getSessionAttributes().put("name", chatMessage.getSender());
		 System.out.println("헤더 액세서는 머야??");
		 System.out.println("심플메세지헤더 액세서 실헝  :" + headerAccessor.getSessionAttributes());
		 messagingTemplate.convertAndSend(format("/chat-room/%s", roomId), chatMessage);
	}
	
}
